<?php
if (in_array($userID, $admins)){
if($msg == 'ping' || $msg == '/ping' || $msg == 'ربات' || $msg == 'آنلاینی' || $msg == 'انلاینی'){
$MadelineProto->messages->sendMessage(['peer' => $chatID, 'reply_to_msg_id' => $msg_id ,'message' => "<b>پ ن پ افلاینم</b>😂",'parse_mode' => 'html']);
}
}
if ($msg =="/chatid" ||$msg=="!chatid" ||$msg=="#chatid"){ 
      $MadelineProto->messages->sendMessage(['peer' =>$chatID,'reply_to_msg_id' => $msg_id ,'message' =>  "$chatID",'parse_mode' => 'MarkDown']); 
} 


/*
@heart_app
*/

